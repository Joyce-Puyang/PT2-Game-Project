#include <graphics.h>
#include "GameManager.hpp"

int main() {
    initwindow(400, 200, "GameManager Test");
    GameManager gm;
    gm.run();         // show game running
    delay(1000);
    gm.nextLevel();   // go to level 2
    delay(1000);
    gm.handleInput(); // simulate input
    delay(1000);
    gm.switchScreen(); // switch screen
    delay(1000);
    getch();
    closegraph();
    return 0;
}
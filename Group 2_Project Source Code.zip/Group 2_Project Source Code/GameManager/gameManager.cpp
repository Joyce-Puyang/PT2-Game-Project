#include "GameManager.hpp"
#include <graphics.h>
#include <stdio.h>

GameManager::GameManager() 
    : currentLevel(1), player(0), activeDart(false), currentScreen(0), score(0) { }

// Indicate game is running
void GameManager::run() {
    char msg[20];
    sprintf (msg, "GameManager: Game running");
    outtextxy(10, 10, msg); 
}

// Advance level and display
void GameManager::nextLevel() {
    currentLevel++;
    char msg[30];
    sprintf(msg, "GameManager: Level %d", currentLevel);
    outtextxy(10, 30, msg);
}

// Simulate handling input
void GameManager::handleInput() {
    char msg[20];
    sprintf (msg, "GameManager: Handling input");
    outtextxy(10, 50, msg);
}

// Simulate screen switch
void GameManager::switchScreen() {
    currentScreen = 1 - currentScreen;
    char msg[20];
    sprintf (msg, "GameManager: Switched screen");
    outtextxy(10, 70, msg);
}
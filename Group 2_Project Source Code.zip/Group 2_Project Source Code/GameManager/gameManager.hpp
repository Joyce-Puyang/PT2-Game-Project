#ifndef GAMEMANAGER_HPP
#define GAMEMANAGER_HPP

class GameManager {
private:
    int currentLevel;
    int player;         // placeholder for player reference
    bool activeDart;
    int currentScreen;  // placeholder (e.g., menu=0, game=1)
    int score;
public:
    GameManager();
    void run();         // run game loop
    void nextLevel();   // advance to next level
    void handleInput(); // handle user input
    void switchScreen();// switch between screens
};

#endif 
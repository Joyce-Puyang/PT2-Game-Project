#ifndef DART_H
#define DART_H

#include <graphics.h>
#include <windows.h>
#include <string>

class Dart {
private:
    // Attributes
    int x, y;               // Position of the dart
    int width, height;      // Dimensions of the dart
    bool isShot;            // Flag if dart is shot
    bool isActive;          // Flag if dart is active (not out of screen)
    COLORREF color;         // Color of the dart

    // Composition: The triangle points are part-of the dart
    POINT arrowHead[3];     // Triangle points for arrowhead

    // Helper methods
    void calculateArrowHead();  // Calculate triangle points based on position

public:
    // Constructors and destructor
    Dart(int startX, int startY, COLORREF dartColor = CYAN);
    ~Dart();

    // Accessors
    int getX() const;
    int getY() const;
    bool getIsShot() const;
    bool getIsActive() const;

    // Mutators
    void setX(int newX);
    void setY(int newY);
    void setIsShot(bool shot);
    void setIsActive(bool active);

    // Display-related methods
    void draw() const;
    void undraw() const;

    // Action-related methods
    void moveHorizontal(int direction);  // Move left or right
    void shoot();                       // Shoot the dart vertically
    void update();                      // Update dart position and state
    bool isOutOfScreen() const;         // Check if dart is out of screen
};

#endif // DART_H
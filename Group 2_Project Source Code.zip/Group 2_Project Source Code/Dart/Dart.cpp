#include "Dart.h"

Dart::Dart(int startX, int startY, COLORREF dartColor) {
    x = startX;
    y = startY;
    width = 30;
    height = 50;
    color = dartColor;
    isShot = false;
    isActive = true;
    calculateArrowHead();
}

Dart::~Dart() {
    // Clean up if needed
}

void Dart::calculateArrowHead() {
    // Calculate triangle points for arrowhead
    arrowHead[0] = {x, y};
    arrowHead[1] = {x - width/4, y + height/3};
    arrowHead[2] = {x + width/4, y + height/3};
}

// Accessors
int Dart::getX() const { return x; }
int Dart::getY() const { return y; }
bool Dart::getIsShot() const { return isShot; }
bool Dart::getIsActive() const { return isActive; }

// Mutators
void Dart::setX(int newX) { 
    x = newX; 
    calculateArrowHead(); // Recalculate arrowhead when position changes
}
void Dart::setY(int newY) { 
    y = newY; 
    calculateArrowHead(); // Recalculate arrowhead when position changes
}
void Dart::setIsShot(bool shot) { isShot = shot; }
void Dart::setIsActive(bool active) { isActive = active; }

// Display-related methods
void Dart::draw() const {
    if (!isActive) return;

    // Draw the shaft (thick line)
    setlinestyle(SOLID_LINE, 0, 3);
    setcolor(color);
    line(x, y + height/3, x, y + height);

    // Draw the fin (smaller line below shaft)
    setlinestyle(SOLID_LINE, 0, 1);
    line(x - width/6, y + height*2/3, x + width/6, y + height*2/3);

    // Draw the arrowhead (triangle)
    setfillstyle(SOLID_FILL, color);
    fillpoly(3, (int*)arrowHead);
}

void Dart::undraw() const {
    if (!isActive) return;

    // Undraw by drawing in background color
    setcolor(BLACK);
    setfillstyle(SOLID_FILL, BLACK);

    // Undraw shaft
    setlinestyle(SOLID_LINE, 0, 3);
    line(x, y + height/3, x, y + height);

    // Undraw fin
    setlinestyle(SOLID_LINE, 0, 1);
    line(x - width/6, y + height*2/3, x + width/6, y + height*2/3);

    // Undraw arrowhead
    fillpoly(3, (int*)arrowHead);
}

// Action-related methods
void Dart::moveHorizontal(int direction) {
    if (isShot || !isActive) return; // Can't move if shot or inactive

    undraw();
    x += direction * 10; // Move left or right
    calculateArrowHead();
    draw();
}

void Dart::shoot() {
    if (isShot || !isActive) return;
    isShot = true;
}

void Dart::update() {
    if (!isShot || !isActive) return;

    undraw();
    y -= 15; // Move up when shot
    calculateArrowHead();
    draw();

    if (isOutOfScreen()) {
        isActive = false;
    }
}

bool Dart::isOutOfScreen() const {
    return y + height < 0; // Check if completely above the screen
}
#include "Dart.h"
#include <iostream>
#include <sstream>
#include <conio.h>

using namespace std;

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;
const int DARTS_COUNT = 3;

// Function prototypes
void initializeGraphics();
void displayInstructions(int dartsLeft);
void gameOverScreen();

int main() {
    initializeGraphics();
    
    // Aggregation: The game has darts (but darts can exist independently)
    Dart* darts[DARTS_COUNT];
    int currentDart = 0;
    int dartsLeft = DARTS_COUNT;
    
    // Initialize all darts at starting position
    for (int i = 0; i < DARTS_COUNT; i++) {
        darts[i] = new Dart(SCREEN_WIDTH/2, SCREEN_HEIGHT - 100);
    }
    
    // Draw initial dart
    darts[currentDart]->draw();
    displayInstructions(dartsLeft);
    
    bool gameRunning = true;
    
    while (gameRunning) {
        // Check for keyboard input
        if (kbhit()) {
            char key = getch();
            
            switch (tolower(key)) {
                case 'a': // Move left
                    darts[currentDart]->moveHorizontal(-1);
                    break;
                case 'd': // Move right
                    darts[currentDart]->moveHorizontal(1);
                    break;
                case ' ': // Shoot
                    darts[currentDart]->shoot();
                    break;
                case 27: // ESC key
                    gameRunning = false;
                    break;
            }
        }
        
        // Update all darts
        for (int i = 0; i < DARTS_COUNT; i++) {
            if (darts[i]->getIsShot() && darts[i]->getIsActive()) {
                darts[i]->update();
                
                // Check if current dart is out of screen
                if (darts[i]->isOutOfScreen()) {
                    dartsLeft--;
                    displayInstructions(dartsLeft);
                    
                    // Switch to next available dart
                    if (dartsLeft > 0) {
                        currentDart = (currentDart + 1) % DARTS_COUNT;
                        while (!darts[currentDart]->getIsActive()) {
                            currentDart = (currentDart + 1) % DARTS_COUNT;
                        }
                        darts[currentDart]->draw();
                    } else {
                        gameOverScreen();
                        delay(2000);
                        gameRunning = false;
                    }
                }
            }
        }
        
        delay(50); // Small delay to reduce CPU usage
    }
    
    // Clean up
    for (int i = 0; i < DARTS_COUNT; i++) {
        delete darts[i];
    }
    
    closegraph();
    return 0;
}

void initializeGraphics() {
    initwindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Dart Shooting Game");
    setbkcolor(BLACK);
    cleardevice();
}

void displayInstructions(int dartsLeft) {
    setcolor(WHITE);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 2);
    
    // Clear previous text area
    setfillstyle(SOLID_FILL, BLACK);
    bar(0, 0, SCREEN_WIDTH, 30);
    
    // Display instructions
    ostringstream oss;
    oss << "A:Left|D:Right|SPACE:Shoot|Darts: " << dartsLeft;
    outtextxy(10, 10, const_cast<char*>(oss.str().c_str()));
}

void gameOverScreen() {
    cleardevice();
    setcolor(MAGENTA);
    settextstyle(DEFAULT_FONT, HORIZ_DIR, 5);
    outtextxy(SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 - 30, "GAME OVER");
}
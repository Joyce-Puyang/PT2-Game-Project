// main_GameScreen.cpp
#include <graphics.h>
#include "GameScreen.h"

int main(){
	initwindow(300, 150, "GameScreen Test");
	GameScreen screen(BLUE);
	screen.handleInput();   //aaply background and text
	getch();
	closegraph();
	return 0;
}
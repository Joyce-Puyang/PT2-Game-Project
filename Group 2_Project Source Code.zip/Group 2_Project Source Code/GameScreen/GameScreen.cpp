// GameScreen.cpp
#include "GameScreen.h"
#include <graphics.h>

GameScreen::GameScreen(int bgColor) : background(bgColor) { }

// Set background color and display message
void GameScreen::handleInput() {
    setbkcolor(background);
    clearviewport();
   outtextxy(50, 50, const_cast<char*>("GameScreen: Input handled"));

}
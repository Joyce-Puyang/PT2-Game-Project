#ifndef GAMESCREEN_H
#define GAMESCREEN_H

#define COLOR_WHITE 0xFFFFFF // Example color definition, replace with actual color values

class GameScreen {
private:
    int background;  // background color index
public:
    GameScreen(int bgColor = COLOR_WHITE);
    void handleInput(); // draw background and handle input
};

#endif // GAMESCREEN_H


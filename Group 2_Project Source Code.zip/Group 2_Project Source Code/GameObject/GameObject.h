#pragma once
#include <graphics.h>
#include <windows.h>
#include <string>

class GameObject {
private:
    int x, y;           // Position of the dart
    int speed;          // Movement speed
    bool isShooting;    // Flag to check if dart is shooting up
    int screenWidth;    // Screen width
    int screenHeight;   // Screen height

public:
    // Constructor & Destructor
    GameObject(int initialX, int initialY, int initialSpeed, int width, int height);
    ~GameObject();

    // Accessors
    int getX() const;
    int getY() const;
    int getSpeed() const;
    bool getIsShooting() const;

    // Mutators
    void setX(int newX);
    void setY(int newY);
    void setSpeed(int newSpeed);
    void setIsShooting(bool shooting);

    // Display-related methods
    void draw() const;
    void undraw() const;
    void displayInfo() const;
    void displayInstructions() const;

    // Action-related methods
    void moveLeft();
    void moveRight();
    void shoot();
    void update();
};
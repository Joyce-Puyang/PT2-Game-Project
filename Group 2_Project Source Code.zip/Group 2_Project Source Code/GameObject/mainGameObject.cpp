#include "GameObject.h"

int main() {
    int screenWidth = 800;
    int screenHeight = 600;
    initwindow(screenWidth, screenHeight, "Dart Shooter Game");

    GameObject dart(screenWidth / 2, screenHeight - 20, 10, screenWidth, screenHeight);
    dart.draw();

    while (true) {  // Changed from while(!kbhit())
        cleardevice();

        // Exit on ESC key
        if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
            break;
        }

        // Movement controls
        if (GetAsyncKeyState('A') & 0x8000) {
            dart.moveLeft();
        }
        if (GetAsyncKeyState('D') & 0x8000) {
            dart.moveRight();
        }
        if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
            dart.shoot();
        }

        dart.update();
        dart.displayInfo();
        dart.displayInstructions();
        dart.draw();

        delay(50);
    }

    closegraph();
    return 0;
}
#include "GameObject.h"

// Constructor
GameObject::GameObject(int initialX, int initialY, int initialSpeed, int width, int height)
    : x(initialX), y(initialY), speed(initialSpeed), isShooting(false),
      screenWidth(width), screenHeight(height) {}

// Destructor
GameObject::~GameObject() {}

// Accessors
int GameObject::getX() const { return x; }
int GameObject::getY() const { return y; }
int GameObject::getSpeed() const { return speed; }
bool GameObject::getIsShooting() const { return isShooting; }

// Mutators
void GameObject::setX(int newX) { x = newX; }
void GameObject::setY(int newY) { y = newY; }
void GameObject::setSpeed(int newSpeed) { speed = newSpeed; }
void GameObject::setIsShooting(bool shooting) { isShooting = shooting; }

// Display the dart (vertical line)
void GameObject::draw() const {
    setcolor(WHITE);
    line(x, y, x, y - 20); // Draw a vertical line (dart)
}

// Undraw the dart (for movement)
void GameObject::undraw() const {
    setcolor(BLACK);
    line(x, y, x, y - 20);
}

// Display position and speed info
void GameObject::displayInfo() const {
    char info[100];
    sprintf(info, "Position: (%d, %d) | Speed: %d", x, y, speed);
    outtextxy(10, 10, info);
}

// Display instructions
void GameObject::displayInstructions() const {
    outtextxy(10, 30, "Press A to move left, D to move right, SPACE to shoot");
}

// Move left
void GameObject::moveLeft() {
    if (x - speed >= 0) {
        undraw();
        x -= speed;
        draw();
    }
}

// Move right
void GameObject::moveRight() {
    if (x + speed <= screenWidth) {
        undraw();
        x += speed;
        draw();
    }
}

// Shoot vertically up
void GameObject::shoot() {
    isShooting = true;
}

// Update dart position (for shooting)
void GameObject::update() {
    if (isShooting) {
        undraw();
        y -= speed * 2; // Move faster when shooting
        draw();

        // Reset if dart goes off-screen
        if (y <= 0) {
            undraw();
            y = screenHeight - 20;
            isShooting = false;
            draw();
        }
    }
}
#ifndef LEVEL_H
#define LEVEL_H

class Level
{
    private :
        int levelCount;
    
    public :
        Level(int count = 1); 
        void startLevel();
        void increaseDifficulty();
        void spawnTarget();
        void displayCenteredText(const char* text);
};

#endif // LEVEL_H
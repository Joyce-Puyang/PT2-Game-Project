#include "Level.h"
#include <graphics.h>

int main ()
{
    Level level(1);
    initwindow(1400, 800, "Game Level");
    rectangle (100, 100, 1300, 700);
    rectangle (90, 90, 1310, 710);

    settextstyle (SANS_SERIF_FONT, HORIZ_DIR, 7);

    level.startLevel();
    getch(); // Wait for 2 second
    level.startLevel();
    getch();
    level.startLevel();
    getch();
    level.startLevel();
    getch();
    level.startLevel();
    
    getch(); // Wait for a key press
    closegraph(); // Close the graphics window
     
    return 0;
}
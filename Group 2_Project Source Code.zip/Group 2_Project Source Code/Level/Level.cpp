#include "Level.h"
#include <iostream>
#include <graphics.h>
#include <stdio.h>

Level :: Level (int count) : levelCount (count) {}

void Level :: displayCenteredText(const char* text)
{
    int textWidth = textwidth((char*)text);
    int textHeight = textheight((char*)text);
    int x = (getmaxx() - textWidth) / 2; // Center horizontally
    int y = (getmaxy() - textHeight) / 2; // Center vertically
    outtextxy(x, y, (char*)text);
}
void Level :: startLevel()
{
    char levelText[100];
    sprintf (levelText, "Level : %d", levelCount);
    displayCenteredText(levelText);
    levelCount++;
}

void Level :: increaseDifficulty()
{
    levelCount++;
    char levelText[100];
    sprintf (levelText, "Difficulty : %d", levelCount);
    displayCenteredText(levelText);
}

void Level :: spawnTarget()
{
    char levelText[100];
    sprintf (levelText, "Spawning new target....! %d");
    displayCenteredText(levelText);
}
#include "Score.h"
#include <iostream>
#include <graphics.h>
#include <stdio.h>

int main()
{
    Score score(0);
    initwindow(1400, 800, "Level Screen");
    rectangle (40, 40, 1350, 750);

    settextstyle (SANS_SERIF_FONT, HORIZ_DIR, 3);

    score.increase();
    getch(); // Wait for a key press
    score.increase();
    getch(); 
    score.increase();
    getch();
    score.displayScore();
    getch();
    score.increase();
    getch();
    score.displayScore();
    
    getch(); 
    closegraph(); // Close the graphics window
     
    return 0;
}
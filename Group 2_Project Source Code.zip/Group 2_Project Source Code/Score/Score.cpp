#include "Score.h"
#include <iostream>
#include <graphics.h>
#include <stdio.h>

Score :: Score (int pts) : points(pts) {}

void Score :: displayCenteredText(int y,const char* text)
{
    int textWidth = textwidth((char*)text);
    int textHeight = textheight((char*)text);
    int x = (getmaxx() - textWidth) / 2; // Center horizontally
    outtextxy(x, y, (char*)text);
}

void Score :: increase() 
{
    points= points + 10; // Increase score by 10 points
    char levelText[100];
    sprintf (levelText, "Points : %d", points);
    displayCenteredText(50,levelText);
}

void Score :: reset()
{
    points = 0;
    char levelText[100];
    sprintf (levelText, "Score reset to : %d");
    displayCenteredText(50,levelText);
}

void Score :: displayScore()
{
    char levelText[100];
    sprintf (levelText, "Score : %d ", points);
    displayCenteredText(50,levelText);
}


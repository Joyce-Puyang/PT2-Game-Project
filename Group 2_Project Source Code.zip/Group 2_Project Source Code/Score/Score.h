#ifndef SCORE_H
#define SCORE_H

class Score
{
    private :
        int points;
    
    public :
        Score(int pts = 0);
        void increase();
        void reset();
        void displayScore();
        void displayCenteredText(int y,const char* text);
};

#endif // SCORE_H

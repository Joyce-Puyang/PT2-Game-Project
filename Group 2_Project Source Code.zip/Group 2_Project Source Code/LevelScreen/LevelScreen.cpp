#include "LevelScreen.h"
#include <graphics.h>
#include <iostream>
#include <math.h>
#include <stdio.h>
#define M_PI 3.14159265358979323846

LevelScreen :: LevelScreen (int lvl ) : level (lvl) {}

void  LevelScreen :: displayCenteredText(const char* text)
{
    int textWidth = textwidth((char*)text);
    int textHeight = textheight((char*)text);
    int x = (getmaxx() - textWidth) / 2; // Center horizontally
    int y = (getmaxy() - textHeight) / 2; // Center vertically
    outtextxy(x, y, (char*)text);
}

void LevelScreen :: displayLevel()
{
    char levelText[100];
    sprintf(levelText, "updating level  %d ....", level);
    displayCenteredText(levelText);
}

void LevelScreen ::  updateLevel()
{
    level++;
    char levelText[100];
    sprintf(levelText, "Current Level : %d", level);
    int textWidth = textwidth((char*)levelText);
    int x = (getmaxx() - textWidth) / 2; // Center horizontally
    outtextxy(x, 50, (char*)levelText);
}

void LevelScreen :: heart(int x, int y, int size) 
{
    setfillstyle(SOLID_FILL, RED);
    for (double t = 0; t < 2 * M_PI; t += 0.001) 
    {
        double px = 16 * pow(sin(t), 3);
        double py = 13 * cos(t) - 5 * cos(2 * t) - 2 * cos(3 * t) - cos(4 * t);

        int screenX = x + (int)(px * size / 10.0);
        int screenY = y - (int)(py * size / 10.0);

        putpixel(screenX, screenY, RED);
    }

     floodfill(x, y, RED);
}



#include "LevelScreen.h"
#include <graphics.h>

int main ()
{
    LevelScreen ls (2);
    initwindow(1400, 800, "Level Screen");
    rectangle (40, 40, 1350, 750);
    
    ls.heart(1200,60, 7);
    ls.heart(1250,60, 7);
    ls.heart(1300,60, 7);

    settextstyle (SANS_SERIF_FONT, HORIZ_DIR, 3);

    ls.updateLevel();
    getch();
    ls.updateLevel();
    getch();
    ls.updateLevel();
    
    getch(); // Wait for a key press
    closegraph(); // Close the graphics window
     
    return 0;
}
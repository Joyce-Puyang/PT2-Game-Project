#ifndef LEVELSCREEN_H
#define LEVELSCREEN_H

class LevelScreen
{
    private :
        int level;
    
    public :
        LevelScreen (int level = 1);
        void displayLevel();
        void updateLevel();
        void displayCenteredText(const char* text);
        void heart(int x, int y, int size = 5);
};

#endif // LEVELSCREEN_H
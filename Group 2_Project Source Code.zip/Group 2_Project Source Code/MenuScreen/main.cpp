#include <graphics.h>
#include "MenuScreen.h"

int main() {
    initwindow(400, 400, "MenuScreen Test");

    MenuScreen menu;
    menu.showMenu();  // Display the menu

    while (true) {
        if (ismouseclick(WM_LBUTTONDOWN)) {
            int x, y;
            getmouseclick(WM_LBUTTONDOWN, x, y);
            menu.handleMouseClick(x, y);

            delay(1500);       // Let user read the output
            menu.showMenu();   // Return to menu after showing a screen
        }

        if (kbhit()) break;  // Exit when a key is pressed
    }

    closegraph();
    return 0;
}
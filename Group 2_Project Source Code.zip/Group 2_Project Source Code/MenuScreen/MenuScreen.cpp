#include "MenuScreen.h"
#include <graphics.h>

MenuScreen::MenuScreen(bool play, bool tut) 
    : playButton(play), tutorialButton(tut) { }

void MenuScreen::showMenu() {
    cleardevice(); // Clear screen

    // Play Button
    int playLeft = 100, playTop = 100, playRight = 300, playBottom = 180;
    rectangle(playLeft, playTop, playRight, playBottom);
    outtextxy(playLeft + 70, playTop + 30, (char*)"Play");

    // Tutorial Button
    int tutLeft = 100, tutTop = 200, tutRight = 300, tutBottom = 280;
    rectangle(tutLeft, tutTop, tutRight, tutBottom);
    outtextxy(tutLeft + 70, tutTop + 30, (char*)"Tutorial");
}

void MenuScreen::startGame() {
    cleardevice();
    int screenWidth = getmaxx();
    int screenHeight = getmaxy();
    const char* msg = "Game is starting...";
    outtextxy(screenWidth / 2 - textwidth((char*)msg) / 2,
              screenHeight / 2 - textheight((char*)msg) / 2,
              (char*)msg);
}

void MenuScreen::showTutorial() {
    cleardevice();
    int screenWidth = getmaxx();
    int screenHeight = getmaxy();
    const char* msg = "Tutorial screen...";
    outtextxy(screenWidth / 2 - textwidth((char*)msg) / 2,
              screenHeight / 2 - textheight((char*)msg) / 2,
              (char*)msg);
}
void MenuScreen::handleMouseClick(int x, int y) {
    // Play Button bounds
    if (x >= 100 && x <= 300 && y >= 100 && y <= 180) {
        startGame();
    }
    // Tutorial Button bounds
    else if (x >= 100 && x <= 300 && y >= 200 && y <= 280) {
        showTutorial();
    }
}
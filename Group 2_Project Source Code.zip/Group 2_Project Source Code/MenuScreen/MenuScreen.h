#ifndef MENUSCREEN_H
#define MENUSCREEN_H

class MenuScreen {
private:
    bool playButton;
    bool tutorialButton;

public:
    MenuScreen(bool play = true, bool tut = false);

    void showMenu();        // Draw menu with buttons
    void startGame();       // Simulate pressing "Play"
    void showTutorial();    // Simulate pressing "Tutorial"
    void handleMouseClick(int x, int y); // Handles click logic
};

#endif // MENUSCREEN_H
#include "Player.hpp"
#include <graphics.h>
#include <stdio.h>  // for sprintf

Player::Player(int initialLives) : lives(initialLives) { }

// Draw a line as a dart and display text
void Player::fireDart() {

    char msg[20];
    sprintf (msg, "Player fired a dart! ");
    outtextxy(10, 20, msg);  // show dart fired message
}

// Display a message that the score increased
void Player::increasesScore() {
    char msg[20];
    sprintf (msg, "Player score increased!  "); 
    outtextxy(10, 40, msg);  // show dart fired message
}

// Decrement lives and display the new count
void Player::decreaseLives() {
    if (lives > 0) lives--;
    char msg[20];
    sprintf(msg, "Lives: %d", lives);
    outtextxy(10, 60, msg);  // show updated lives
}
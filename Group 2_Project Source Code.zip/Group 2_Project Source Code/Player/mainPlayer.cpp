#include <graphics.h>
#include "Player.hpp"

int main() {
    initwindow(300, 200, "Player Test");  // create graphics window
    Player p(3);
    p.increasesScore();  // display score increase
    p.fireDart();    
    delay(1000);
    delay(1000);
    p.decreaseLives();   // decrement and display lives
    delay(1000);
    getch();             // wait for key press
    closegraph();
    
    return 0;
}
#ifndef PLAYER_H
#define PLAYER_H

class Player {
private:
    int lives;             // number of lives remaining
public:
    // Constructor initializes lives (default 3)
    Player(int initialLives = 3);

    void fireDart();       // simulate firing a dart
    void increasesScore(); // simulate increasing score
    void decreaseLives();  // decrement lives and display it
};

#endif // PLAYER_H